<?php

namespace App\Http\Controllers;

use App\Models\Car;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use ValidateRequests;


class CarController extends Controller
{
    public function index() {
        $car = Car::where('user_id', Auth::user()->id)->get();
        $userId = Auth::id();
        return view('request.index', compact('car', 'userId'));
    }
    
    public function create() {
        return view('car.create');
    }

    public function store(Car $car): RedirectResponse {
        $car->validate([
            'name' => ['required', 'string'],
            'model' => ['required', 'string'],
            'make' => ['required', 'string']
        ]);

        Car::create([
            'car' => $car->name,
            'model' => $car->model,
            'make'=> $car->make,
            "user_id" => Auth::user()->id
        ]);

        return redirect()->route('dashboard');
    }

    public function show(Car $car){
        return view('car.show', compact('car'));
    }
}
