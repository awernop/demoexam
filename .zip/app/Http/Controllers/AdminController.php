<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\Request as modelRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index(){
        $cars = Car::all();
        $requests = modelRequest::all();
        return view('admin.index', compact('cars', 'requests'));
    }
}
