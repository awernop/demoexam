<?php

namespace App\Http\Controllers;

use App\Models\Request as modelRequest;
use App\Models\Car;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class RequestController extends Controller
{
    public function index() {
        $requests = modelRequest::where('user_id', Auth::user()->id)->get();
        $cars = Car::all();
        $userId = Auth::id();
        return view('request.index', compact('requests', 'userId', 'cars'));
    }

    public function create() {
        $cars = Car::all();
        return view('request.create', compact('cars'));
    }

    public function store(modelRequest $request, Car $car): RedirectResponse {
        $request->validate([
            'description' => ['required', 'string']
        ]);

        modelRequest::create([
            'car_id' => $car->id,
            'description' => $request->description,
            "user_id" => Auth::user()->id
        ]);

        return redirect()->route('dashboard');
    }

    public function show(modelRequest $request){
        return view('request.show', compact('request'));
    }
}
