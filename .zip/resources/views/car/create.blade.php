<x-app-layout>
    <x-slot name="header">
        <h2 class="text-3xl font-bold py-5">{{ __('Создание нового авто')}}</h2>
    </x-slot>
    
    <form class="mx-auto max-w-2xl p-4 md:p-5 space-y-4 flex flex-col gap-5" method="POST" action="{{route('car.store')}}">
        @csrf
        <div class="flex flex-col gap-5">
            <!-- Name -->
            <div>
                <x-input-label for="name" :value="__('Номер автомобиля')"/>
                <x-text-input id="name" class="block mt-1" type="text" name="name" required/>
                <x-input-error :messages="$errors->get('name')" class="mt-2" />
            </div>
            <!-- Model -->
            <div>
                <x-input-label for="model" :value="__('Модель')"/>
                <x-text-input id="model" class="block mt-1" type="text" name="model" required/>
                <x-input-error :messages="$errors->get('model')" class="mt-2" />
            </div>
            <!-- Mark -->
            <div>
                <x-input-label for="mark" :value="__('Марка')"/>
                <x-text-input id="mark" class="block mt-1" type="text" name="mark" required/>
                <x-input-error :messages="$errors->get('mark')" class="mt-2" />
            </div>
            <div>
                <x-primary-button class="ms-3">
                    {{__('Создать')}}
                </x-primary-button>
            </div>
        </form>
    </div>
</x-app-layout>