<x-guest-layout>
<h2 class="text-blue-700 text-2xl text-center font-semibold imask mb-2">Регистрация</h2>
<form method="POST" action="{{ route('register') }}" class="flex flex-col gap-2">
        @csrf
        <!-- Surname -->
        <div>
            <x-input-label for="surname" :value="__('Введите фамилию')" />
            <x-text-input id="surname" class="block mt-1 w-full" type="text" name="surname" :value="old('surname')" required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('surname')" class="mt-2" />
        </div>

        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Введите имя')" />
            <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

        <!-- Email Address -->
        <div>
            <x-input-label for="email" :value="__('Введите электронную почту')" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autocomplete="email" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Date -->
        <div>
            <x-input-label for="data_birth" :value="__('Введите дату рождения')" />
            <input type='date' id="data_birth" class="block mt-1 w-full" name="data_birth" :value="old('data_birth')" required autocomplete="tel" />
            <x-input-error :messages="$errors->get('data_birth')" class="mt-2" />
        </div>

        <!-- Phone -->
        <div>
            <x-input-label for="tel" :value="__('Введите телефон')" />
            <x-text-input id="tel" class="block mt-1 w-full" name="tel" :value="old('tel')" required autocomplete="tel" />
            <x-input-error :messages="$errors->get('tel')" class="mt-2" />
        </div>

        <!-- Password -->
        <div>
            <x-input-label for="password" :value="__('Введите пароль')" />

            <x-text-input id="password" class="block mt-1 w-full"
                            type="password"
                            name="password"
                            required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password
        <div>
            <x-input-label for="password_confirmation" :value="__('Повторите пароль')" />

            <x-text-input id="password_confirmation" class="block mt-1 w-full"
                            type="password"
                            name="password_confirmation" required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div> -->

        <div class="flex items-center justify-end">
            <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="{{ route('login') }}">
                {{ __('Уже зарегистрированы?') }}
            </a>

            <x-primary-button class="ms-4">
                {{ __('Создать аккаунт') }}
            </x-primary-button>
        </div>
    </form>
</x-guest-layout>
