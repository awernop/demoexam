
<x-app-layout>
<a class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-350" href="{{ route('car.create') }}">
                {{ __('СОЗДАТЬ МАШИНУ') }}
            </a>

<div class="py-12">
  <div class="max-w-7x1 mx-auto sm:px-6 lg:px-8">
  
          <div class='flex flex-wrap gap-4'>
          @foreach($cars as $car)
        <div class='div-col border bg-gray-200 rounded-md p-6 mt-4 w-80'>
          <p class="text-sm text-gray-500">{{\Carbon\Carbon::parse($car->created_at)->translatedFormat('j F Y')}}</p>
          <span class='text-xl font-semibold'>{{$car->name}}</span>
          <span class='text-xl font-semibold'>{{$car->make}}</span>
          <span class='text-xl font-semibold'>{{$car->model}}</span>
        </div>
      @endforeach
          </div>
      
    </div>
    @if(count($cars)===0)
    <div class="flex place-content-center pt-48">
      <span class='font-semibold text-4xl uppercase tracking-widest text-gray-300'>Пока тут ничего нет</span>
    </div>
    @endif
  </div>
</div>
</x-app-layout>
