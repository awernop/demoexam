<x-app-layout>
    <x-slot name="header">
        <h2 class="text-3xl font-bold py-5">{{ __('Создание новой заявки')}}</h2>
    </x-slot>
    
    <form class="mx-auto max-w-2xl p-4 md:p-5 space-y-4 flex flex-col gap-5" method="POST" action="{{route('request.store')}}">
        @csrf
        <div class="flex flex-col gap-5">
            <!-- Car -->
            <div>
                <select name="name" id="name">
                    @foreach($car in $cars)
                        <option value="{{$car->id}}">$car->name</option>
                    @endforeach
                </select>
               <x-input-error :messages="$errors->get('car_id')" class="mt-2" />
            </div>
            <!-- Desription -->
            <div>
                <x-input-label for="description" :value="__('Описание')"/>
                <x-textarea id="description" class="block mt-1" rows="10" cols="35" name="description" required/>
                <x-input-error :messages="$errors->get('description')" class="mt-2" />
            </div>
            <div>
                <x-primary-button class="ms-3">
                    {{__('Создать')}}
                </x-primary-button>
            </div>
        </form>
    </div>
</x-app-layout>